define({
  "name": "e-planet",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-11-23T10:31:21.516Z",
    "url": "http://apidocjs.com",
    "version": "0.20.1"
  }
});
